# -*- coding=utf8 -*-

import MySQLdb


class MysqlManager(object):
    '''mysql管理器'''

    # def __init__(self, db, user, passwd, host='121.196.111.9', port=3306, charset='utf8'):
    def __init__(self, db, user, passwd, host='8.131.235.164', port=3306, charset='utf8'):
        '''初始化数据库'''
        self.__db = db
        self.__user = user
        self.__passwd = passwd
        self.__host = host
        self.__port = port
        self.__charset = charset
        self.__connect = None
        self.__cursor = None

    def _connect_db(self):
        """
            dbManager._connect_db()
        连接数据库
        """
        params = {
            "db": self.__db,
            "user": self.__user,
            "passwd": self.__passwd,
            "host": self.__host,
            "port": self.__port,
            "charset": self.__charset
        }
        self.__connect = MySQLdb.connect(**params)
        self.__cursor = self.__connect.cursor()

    def _close_db(self):
        self.__cursor.close()
        self.__connect.close()

    def get_res(self, name, password):
        self._connect_db()

        sql = "select * from blog_user where name = '%s' and password = '%s'""" % (name, password)
        self.__cursor.execute(sql)
        print(sql)

        result = self.__cursor.fetchall()
        self._close_db()

        jsonData = []
        for row in result:
            data = {'name': row[0], 'password': row[1]}
            jsonData.append(data)
        return jsonData

    def get_data_contract(self, show_list, condition=None, get_one=False):

        self._connect_db()

        # 处理显示的数据
        show_list = ",".join(show_list)
        sql = "select {key} from blog_content ".format(key=show_list)
        # 处理传入的条件
        if condition:
            condition_list = self._deal_values(condition)
            condition_data = ''.join(condition_list)
            sql = "select {key} from blog_content where name like{condition}".format(key=show_list,
                                                                                     condition=condition_data)

        self.__cursor.execute(sql)
        # 返回一条数据还是所有数据
        if get_one:
            result = self.__cursor.fetchone()
        else:
            result = self.__cursor.fetchall()
        self._close_db()

        jsonData = []
        for row in result:
            data = {'name': row[0], 'title': row[2], 'content': row[1], 'time': row[3]}
            jsonData.append(data)
        print(jsonData)
        return jsonData

    def insert_res(self, name, password):
        '''
            dbManager.insert(table, insert_data)
        添加数据到数据库
        str -> table 为字符串
        [{},{}] -> 为列表中嵌套字典类型
        '''
        # 用户传入数据字典列表数据，根据key, value添加进数据库
        # 连接数据库
        self._connect_db()

        try:
            # 构建sql语句
            sql = "insert into blog_user (name,password) values ('%s', '%s')""" % (name, password)

            self.__cursor.execute(sql)
            self.__connect.commit()
        except Exception as error:
            print
            'error'
        finally:
            self._close_db()

    def insert_data_contract(self, name, title, content, time):
        '''
            dbManager.insert(table, insert_data)
        添加数据到数据库
        str -> table 为字符串
        [{},{}] -> 为列表中嵌套字典类型
        '''
        # 用户传入数据字典列表数据，根据key, value添加进数据库
        # 连接数据库
        self._connect_db()

        try:
            # 构建sql语句
            sql = "insert into blog_content (name,title,content,time) values ('%s', '%s', '%s', '%s')""" % (name, title, content, time)

            self.__cursor.execute(sql)
            self.__connect.commit()
        except Exception as error:
            print
            'error'
        finally:
            self._close_db()