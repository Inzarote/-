window.onload = function(){
    get_for_index()
}

function createname(name){
    let tableData="";
    tableData+="<tr>";
    tableData+="<td>"+name+"</td>";
    tableData+="</tr>";
    document.getElementById("username").innerHTML=tableData;
}

function get_for_index(){
    $.ajax({
　　　　    url : 'http://127.0.0.1:5000/get_now_username', 　
　　　　    type : 'post',　　　　　　　　
　　　　   dataType : 'json',
　　　　success:function(name){　　　<!--回调函数 -->
        createname(name);
　　　　　},
        error:function () {
        createname("admin");
        }
　　　　});
}

