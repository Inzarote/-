window.onload = function(){

}

function new_user(){
    let user = {};
    user['name']=document.getElementById("user_register").value;

    if (document.getElementById("passwd").value==document.getElementById("passwd2").value){
        user['password']=document.getElementById("passwd").value;

    $.ajax({
　　　　    url : 'http://127.0.0.1:5000/insert_user', 　
　　　　    type : 'post',　　　　　　　　
　　　　    data : JSON.stringify(user),
       contentType:'application/json;charset=UTF-8',
　　　　   dataType : 'json',
　　　　success:function(id){　　　<!--回调函数 -->
        alert("用户创建成功！");
　　　　　},
        error:function (XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.status);//如果有错误抛出异常
            alert(XMLHttpRequest.readyState);
            alert(textStatus);
        }
　　　　});
    }else
    {
        alert("两次密码不同，请重新输入");
        document.getElementById("passwd").value="";
        document.getElementById("passwd2").value="";
    }
}

