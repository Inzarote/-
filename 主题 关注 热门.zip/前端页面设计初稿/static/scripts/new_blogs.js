window.onload = function(){
    opeartor_role();
}

function rewrite(){//重置合同内容
    document.getElementById("blog_title").value="";
    document.getElementById("blog_content").value="";
}

function save_draft(name_index){
    let data = {};
    data['name']="";
    data['title']=document.getElementById("blog_title").value;
    data['content']=document.getElementById("blog_content").value;
    data['time']=new Date().getFullYear()+"/"+new Date().getMonth()+"/"+new Date().getDate()+" "+new Date().getHours()+":"+new Date().getMinutes();
    $.ajax({
　　　　    url : 'http://127.0.0.1:5000/newContract', 　
　　　　    type : 'post',　　　　　　　　
　　　　    data : JSON.stringify(data),
       contentType:'application/json;charset=UTF-8',
　　　　   dataType : 'json',
　　　　success:function(id){　　　<!--回调函数 -->
        window.location.href="blogs.html";
        alert("博客创建成功！");
　　　　　},
        error:function (XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.status);//如果有错误抛出异常
            alert(XMLHttpRequest.readyState);
            alert(textStatus);
        }
　　　　});
}

function get_for_draft(){
    $.ajax({
　　　　   url : 'http://127.0.0.1:5000/get_now_username', 　
　　　　   type : 'post',　　　　　　　　
　　　　   dataType : 'json',
　　　   　success:function(name_index){　　　<!--回调函数 -->
           save_draft(name_index);
　　　　  }
　　　});
}

function opeartor_role(){
    $.ajax({
　　　　   url : 'http://127.0.0.1:5000/opeartor_role', 　
　　　　   type : 'post',　　　　　　　　
　　　　   dataType : 'json',
　　　   　success:function(data_role){　　　<!--回调函数 -->
               alert(data_role[0]['Draftcontract']);
　　　　  }
　　　});
}

