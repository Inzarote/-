window.onload=function (){
    getJsonWmhname3();
}

function creatTableWmh3(data,names){
    const arr = [];
//    alert('daole')
//    alert(datas)
    names = datas
    alert (names)

    for(let i=0; i<data.length; i++){
//    Ndata[i] = data[i]['id'] + "";
      if (data[i]['username'].indexOf(names) >= 0) {
        alert(data[i]['username']);
          arr.push(data[i]);
      }
    }

     if(arr.length==0){//判断结果
         alert("你没关注任何人");//没有符合要求的合同则返回全部
     }
     else {//将模糊查询得到的结果输出
          data=arr;
     }
     let tableData="";

     for(let i=0; i<data.length; i++){
         tableData+="<tr>";
         tableData+="<td width='80'>"+data[i]['username']+"</td>";
         if(data[i]['topic']=='1'){
            tableData+="<td width='80'>动漫杂谈</td>";
         }
         if(data[i]['topic']=='2'){
            tableData+="<td width='80'>资源分享</td>";
         }
         if(data[i]['topic']=='3'){
            tableData+="<td width='80'>同人创作</td>";
         }
         if(data[i]['topic']=='4'){
            tableData+="<td width='80'>舞文弄键</td>";
         }
         tableData+="<td width='80'>"+data[i]['time']+"</td>";
         tableData+="<td width='100'>"+data[i]['title']+"</td>";
         if (data[i]['content'].length>15){
             tableData+="<td width='320'>"+data[i]['content'].substring(0,15)+"……"+"</td>";
         }
         else{
             tableData+="<td width='320'>"+data[i]['content']+"</td>";
         }

         if(data[i]['essence']=='1'){
            tableData+="<td width='50'>未加精</td>";
         }
         if(data[i]['essence']=='2'){
            tableData+="<td width='50'>已加精</td>";
         }

//         tableData+="<td width='50'>"+data[i]['state']+"</td>";
         tableData+="<td width='50'> <input type='button' onclick='open_newWmh1(this)' value='查看'></td>";
         tableData+="</tr>";
     }
    document.getElementById("tbodyWmh3").innerHTML=tableData;
}

function open_newWmh3(obj){
    let a=$(obj).closest("tr").find("td").eq(0).text();
    window.location.href="post_result.html?id="+a;
}


function getJsonWmhname3(){
        $.ajax({
　　　　    url : 'http://127.0.0.1:5000/get_now_username', 　
　　　　    type : 'post',　　　　　　　　
 　　　　   dataType : 'json',
　　　　success:function(name_index){　　　<!--回调函数 -->
            getJsonWmhname33(name_index);
　　　　　},
          error:function (XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.status);//如果有错误抛出异常
            alert(XMLHttpRequest.readyState);
            alert(textStatus);
          }
　　　　});
}

function followWmh3(data,name_index){
    const arr = [];
    alert (name_index)
    for(let i=0; i<data.length; i++){
//    Ndata[i] = data[i]['id'] + "";
      if (data[i]['username'].indexOf(name_index) >= 0) {
//        alert(data[i]['follower']);
        arr.push(data[i]['follower']);
      }
    }
     if(arr.length==0){//判断结果
         alert("你没关注任何人");//没有符合要求的合同则返回全部
     }
     else {//将模糊查询得到的结果输出
          datas=arr;
     }
//     alert('arrflaile')
//     alert(datas)
    return datas;
}

function getJsonWmhname33(name_index){
        $.ajax({
　　　　    url : 'http://127.0.0.1:5000/GetFollow', 　
　　　　    type : 'post',　　　　　　　　
　　　　    data : "id=1",
 　　　　   dataType : 'json',
　　　　success:function(data){　　　<!--回调函数 -->
            followWmh3(data,name_index);
            getJsonWmh3(name_index);
　　　　　},
          error:function (XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.status);//如果有错误抛出异常
            alert(XMLHttpRequest.readyState);
            alert(textStatus);
          }
　　　　});
}

function getJsonWmh3(name_index){
        $.ajax({
　　　　    url : 'http://127.0.0.1:5000/GetBlog', 　
　　　　    type : 'post',　　　　　　　　
　　　　    data : "id=1",
 　　　　   dataType : 'json',
　　　　success:function(data){　　　<!--回调函数 -->
            creatTableWmh3(data,name_index);
　　　　　},
          error:function (XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.status);//如果有错误抛出异常
            alert(XMLHttpRequest.readyState);
            alert(textStatus);
          }
　　　　});
}