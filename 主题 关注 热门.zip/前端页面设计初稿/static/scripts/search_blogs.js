function search(){
    getData(document.getElementById("search1").value);
}

function find(data,keyword){//获取模糊查询结果并输出
    const arr = [];
    for(let i=0; i<data.length; i++){
      if (data[i]['name'].toString().indexOf(keyword) >= 0||data[i]['title'].toString().indexOf(keyword) >= 0) {
          // alert(data[i]['id']);
          arr.push(data[i]);
      }
    }
     let tableData="";
     document.getElementById("tbody1").innerHTML=tableData;
     // alert("156");
     if(arr.length===0){//判断结果
         alert("无符合要求的博客");//没有符合要求的合同则返回全部
     }
     else {//将模糊查询得到的结果输出
          data=arr;
     }
     for(let i=0; i<data.length; i++){
         tableData+="<br>";
         tableData+="<br>";
         tableData+="<tr>";
         tableData+="<td>"+"<img src=\"../static/images/common/asd.jpg\" width=\"35\" height=\"35\">"+"</td>";
         tableData+="<td align='left'>"+data[i]['name']+"<br>"+data[i]['time']+"</td>";
         tableData+="</tr>";
         tableData+="<tr>";
         tableData+="<td width='200'>标题:</td>";
         tableData+="<td>"+data[i]['title']+"</td>";
         tableData+="</tr>";
         tableData+="<tr>";
         tableData+="<td width='200'>博客内容:</td>";
         tableData+="<td>"+data[i]['content']+"</td>";
         tableData+="</tr>";
         tableData+="<br>";
     }
    document.getElementById("tbody1").innerHTML=tableData;
}


function getData(keyword){
        $.ajax({
　　　　    url : 'http://127.0.0.1:5000/getData', 　
　　　　    type : 'post',　　　　　　　　
　　　　    data : "id=1",
 　　　　   dataType : 'json',
　　　　success:function(data){　　　<!--回调函数 -->
        find(data,keyword);
　　　　　},
          error:function (XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.status);//如果有错误抛出异常
            alert(XMLHttpRequest.readyState);
            alert(textStatus);
          }
　　　　});
}