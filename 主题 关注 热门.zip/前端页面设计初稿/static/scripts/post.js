window.onload=function (){
    getJsonWmh13();
}

function creatTableWmh13(data){//创建table
     let tableData="";
     let tableData1="";
     let tableData2="";
     let tableData3="";
     let tableData4="";
     let tableData5="";
     let a=UrlParam.paramValues("id");

     for(let i=0; i<data.length; i++){
         if (data[i]['id'] == a){
         a=i;
         }
         }

         tableData+="<td>"+data[a]['username']+"</td>";

         if(data[i]['topic']=='1'){
            tableData1+="<td width='80'>动漫杂谈</td>";
         }
         if(data[i]['topic']=='2'){
            tableData1+="<td width='80'>资源分享</td>";
         }
         if(data[i]['topic']=='3'){
            tableData1+="<td width='80'>同人创作</td>";
         }
         if(data[i]['topic']=='4'){
            tableData1+="<td width='80'>舞文弄键</td>";
         }

         tableData2+="<td>"+data[a]['time']+"</td>";

         tableData3+="<td>"+data[a]['title']+"</td>";

         tableData4+="<td>"+data[a]['content']+"</td>";

         tableData5+="<tr>";
         tableData5+="<td><input type='button' onclick='SubmitWmh1()' value='返回'></td>" ;
         tableData5+="</tr>";


    document.getElementById("tbodyWmh12").innerHTML=tableData;
    document.getElementById("tbodyWmh13").innerHTML=tableData1;
    document.getElementById("tbodyWmh14").innerHTML=tableData2;
    document.getElementById("tbodyWmh15").innerHTML=tableData3;
    document.getElementById("tbodyWmh16").innerHTML=tableData4;
    document.getElementById("tbodyWmh17").innerHTML=tableData5;
}

function getJsonWmh13(){//获取数据
        $.ajax({
　　　　    url : 'http://127.0.0.1:5000/GetBlog', 　
　　　　    type : 'post',　　　　　　　
 　　　　   dataType : 'json',
　　　　success:function(data){　　　<!--回调函数 -->
            creatTableWmh13(data);
　　　　　},
          error:function (XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.status);//如果有错误抛出异常
            alert(XMLHttpRequest.readyState);
            alert(textStatus);
          }
　　　　});
}

function SubmitWmh1(){//返回
    window.location.href="topic.html";
}