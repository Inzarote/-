window.onload=function (){
    getJson();
}

function creatTable(data){
     let tableData="";
     for(let i=0; i<data.length; i++){
         tableData+="<br>";
         tableData+="<br>";
         tableData+="<tr>";
         tableData+="<td>"+"<img src=\"../static/images/common/asd.jpg\" width=\"35\" height=\"35\">"+"</td>";
         tableData+="<td align='left'>"+data[i]['name']+"<br>"+data[i]['time']+"</td>";
         tableData+="</tr>";
         tableData+="<tr>";
         tableData+="<td width='200'>标题:</td>";
         tableData+="<td>"+data[i]['title']+"</td>";
         tableData+="</tr>";
         tableData+="<tr>";
         tableData+="<td width='200'>博客内容:</td>";
         tableData+="<td>"+data[i]['content']+"</td>";
         tableData+="</tr>";
         tableData+="<br>";
     }
    document.getElementById("tbody1").innerHTML=tableData;
}

function getJson(){
        $.ajax({
　　　　    url : 'http://127.0.0.1:5000/getData', 　
　　　　    type : 'post',　　　　　　　　
　　　　    data : "id=1",
 　　　　   dataType : 'json',
　　　　success:function(data){　　　<!--回调函数 -->
            creatTable(data);
　　　　　},
          error:function (XMLHttpRequest, textStatus, errorThrown) {
          }
　　　　});
}
