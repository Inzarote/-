window.onload=function (){
    getJsonWmh2();
}

function creatTableWmh2(data){
const arr = [];

    for(let i=0; i<data.length; i++){
//    Ndata[i] = data[i]['id'] + "";
      if (data[i]['essence']=='2') {
//        alert(data[i]['username']);
        arr.push(data[i]);
      }
    }
     data=arr;
     let tableData="";

     for(let i=0; i<data.length; i++){
         tableData+="<tr>";
         tableData+="<td width='80'>"+data[i]['username']+"</td>";
         if(data[i]['topic']=='1'){
            tableData+="<td width='80'>动漫杂谈</td>";
         }
         if(data[i]['topic']=='2'){
            tableData+="<td width='80'>资源分享</td>";
         }
         if(data[i]['topic']=='3'){
            tableData+="<td width='80'>同人创作</td>";
         }
         if(data[i]['topic']=='4'){
            tableData+="<td width='80'>舞文弄键</td>";
         }
         tableData+="<td width='80'>"+data[i]['time']+"</td>";
         tableData+="<td width='100'>"+data[i]['title']+"</td>";
         if (data[i]['content'].length>15){
             tableData+="<td width='320'>"+data[i]['content'].substring(0,15)+"……"+"</td>";
         }
         else{
             tableData+="<td width='320'>"+data[i]['content']+"</td>";
         }

         if(data[i]['essence']=='1'){
            tableData+="<td width='50'>未加精</td>";
         }
         if(data[i]['essence']=='2'){
            tableData+="<td width='50'>已加精</td>";
         }

//         tableData+="<td width='50'>"+data[i]['state']+"</td>";
         tableData+="<td width='50'> <input type='button' onclick='open_newWmh1(this)' value='查看'></td>";
         tableData+="</tr>";
     }
    document.getElementById("tbodyWmh2").innerHTML=tableData;
}

function open_newWmh2(obj){
    let a=$(obj).closest("tr").find("td").eq(0).text();
    window.location.href="post_result.html?id="+a;
}

function getJsonWmh2(){
        $.ajax({
　　　　    url : 'http://127.0.0.1:5000/GetBlog', 　
　　　　    type : 'post',　　　　　　　　
　　　　    data : "id=1",
 　　　　   dataType : 'json',
　　　　success:function(data){　　　<!--回调函数 -->
            creatTableWmh2(data);
　　　　　},
          error:function (XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.status);//如果有错误抛出异常
            alert(XMLHttpRequest.readyState);
            alert(textStatus);
          }
　　　　});
}
