from MysqlHelper import MysqlHelper
mh = MysqlHelper('localhost', 'root', 'wyj18301109', 'hentong', 'utf8')
sql = "select * from user where name=%s"
print(mh.find(sql, '张三'))