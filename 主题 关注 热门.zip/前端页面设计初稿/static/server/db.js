//db.js
module.exports = {
    mysql: {
        host: '127.0.0.1', //mysql连接ip地址
        user: 'root',
        password: '', //mySql用户名密码
        database: 'library',
        port: '3306' //mysql连接端口
    }
}
