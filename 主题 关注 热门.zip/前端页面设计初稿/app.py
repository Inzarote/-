import json
import pymysql
from db_connect import MysqlManager

from flask import Flask, render_template, jsonify, request
from werkzeug.debug import console

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
dbManager = MysqlManager("contract", 'yyn', '13141516')


@app.route('/', methods=['GET', 'POST'])
def res():
    if request.method == 'POST':
        name = request.form.get('username')
        password = request.form.get('p')

        dbManager.get_res(name, password)
        data = dbManager.get_res(name, password)
        global name_index
        name_index = name
        return render_template("index.html")

    return render_template("logres.html")


@app.route('/get_now_username', methods=['GET', 'POST'])
def get_now_username():
    print(name_index + "返回名字")
    return json.dumps(name_index)


@app.route('/getData', methods=['GET', 'POST'])
def getData():
    data = dbManager.get_data_contract(['*'])
    return json.dumps(data)


@app.route('/new_blog.html')
def new_blog():
    return render_template("new_blog.html")


@app.route('/index.html')
def index():
    return render_template("index.html")


@app.route('/blogs.html')
def blogs():
    return render_template("blogs.html")


@app.route('/post.html')
def post():
    return render_template("post.html")


@app.route('/hot.html')
def hot():
    return render_template("hot.html")


@app.route('/follow.html')
def follow():
    return render_template("follow.html")


@app.route('/topic.html')
def topic():
    return render_template("topic.html")


@app.route('/function_hot.html')
def function_hot():
    return render_template("function_hot.html")


@app.route('/function_topic.html')
def function_topic():
    return render_template("function_topic.html")


@app.route('/function_follow.html')
def function_follow():
    return render_template("function_follow.html")


@app.route('/insert_user', methods=['GET', 'POST'])
def insert_user():
    data = request.data
    contract = json.loads(data)
    dbManager.insert_res(contract['name'], contract['password'])
    return json.dumps({"error_code": "0", "id": ""})


@app.route('/newContract', methods=['GET', 'POST'])
def InsertContract():
    data = request.data
    contract = json.loads(data)
    contract['name'] = name_index
    print(contract)
    dbManager.insert_data_contract(contract['name'], contract['title'], contract['content'], contract['time'])
    return json.dumps({"error_code": "0", "id": ""})

@app.route('/GetBlog', methods=['GET', 'POST', 'PUT'])
def getBlog():
    return json.dumps([{"id":"1" ,"username": "黑暗圣剑", "topic": "1", "time": "2021-06-13 15:15:05",
                        "title": "求邀", "content": "今天天气不错，出去玩call我，一起看新番", "essence": "1"},
                       {"id":"2" ,"username": "光明圣梦", "topic": "1", "time": "2021-06-10 15:15:05",
                        "title": "天地劫", "content": "今天依然是天地劫time~", "essence": "1"},
                       {"id":"3" ,"username": "言出法随姚", "topic": "2", "time": "2021-06-11 15:15:05",
                        "title": "外包", "content": "今天的甲方爸爸给的钱真多，下次再接一单", "essence": "2"},
                       {"id":"4" ,"username": "无敌楠", "topic": "3", "time": "2021-06-12 15:15:05",
                        "title": "创作diss", "content": "涩图？这不是分分钟给你整出来？", "essence": "1"},
                       {"id":"5" ,"username": "社死人磊", "topic": "4", "time": "2021-06-14 15:15:05",
                        "title": "SAD", "content": "今天开会又社死了，这下不敢去公司了", "essence": "2"},
                       {"id":"6" ,"username": "菜逼昊", "topic": "4", "time": "2021-06-15 15:15:05",
                        "title": "求脱单", "content": "希望邂逅一名美少女，让她看看大宝贝，嘿嘿嘿", "essence": "1"},
                       ])

@app.route('/GetFollow', methods=['GET', 'POST', 'PUT'])
def getFollow():
    return json.dumps([{"username": "黑暗圣剑", "follower": "光明圣梦"},
                       {"username": "光明圣梦", "follower": "言出法随姚"},
                       {"username": "言出法随姚", "follower": "无敌楠"},
                       {"username": "无敌楠", "follower": "社死人磊"},
                       {"username": "社死人磊", "follower": "菜逼昊"},
                       {"username": "菜逼昊", "follower": "黑暗圣剑,社死人磊"},
                       ])



if __name__ == '__main__':
    app.run()
